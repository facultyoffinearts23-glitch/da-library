/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  School,
  Database, 
  GraduationCap, 
  Globe, 
  BookOpen, 
  Search, 
  FolderTree, 
  Link as LinkIcon, 
  CloudUpload, 
  FilePlus, 
  Plus, 
  Shield, 
  Download, 
  LogIn, 
  LogOut, 
  X, 
  ChevronDown, 
  Trash2, 
  Microscope,
  Palette,
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
  Eye,
  Calendar,
  PenTool,
  User,
  Sparkles,
  Info
} from "lucide-react";
import { initializeApp, getApps } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy,
  getDocFromServer
} from "firebase/firestore";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser
} from "firebase/auth";
import { Book, Artwork, UserRole, GuideTab } from "./types";
const collegeLogo = "https://lh3.googleusercontent.com/d/1x_MJZVr019Q5etfwxoLD3EhOMD_kO0JX";

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
      emailVerified: auth?.currentUser?.emailVerified || null,
      isAnonymous: auth?.currentUser?.isAnonymous || null,
      tenantId: auth?.currentUser?.tenantId || null,
      providerInfo: auth?.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Firebase credentials directly extracted from original HTML file
const firebaseConfig = {
  apiKey: "AIzaSyB7fpWIDRXiuf642M0PG4wKr8oLAcIUMlc",
  authDomain: "arts-digital-library.firebaseapp.com",
  databaseURL: "https://arts-digital-library-default-rtdb.firebaseio.com",
  projectId: "arts-digital-library",
  storageBucket: "arts-digital-library.firebasestorage.app",
  messagingSenderId: "1035292297214",
  appId: "1:1035292297214:web:0a881825940c59db9522af"
};

// Lazy initialization of Firebase to prevent crashes if offline or if credentials became unusable
let app;
let db: any = null;
let auth: any = null;

try {
  if (getApps().length === 0) {
    app = initializeApp(firebaseConfig);
  } else {
    app = getApps()[0];
  }
  db = getFirestore(app);
  auth = getAuth(app);
} catch (error) {
  console.error("Firebase Initialization Error:", error);
}

// Default Fallback Books
const INITIAL_MOCK_BOOKS: Book[] = [
  {
    id: "default-book-1",
    title: "تأثير الفن الإسلامي على العمارة الطرابلسية الحديثة",
    author: "منى فرج العزابي",
    tag: "projects",
    year: "2025",
    fileUrl: "https://facultyoffinearts23-glitch.github.io/graduation-archive/",
    timestamp: Date.now() - 10000
  },
  {
    id: "default-book-2",
    title: "علم الجمال وفلسفة التذوق في الفن التشكيلى المعاصر",
    author: "أ.د. عبد السلام الصادق",
    tag: "research",
    year: "2024",
    fileUrl: "https://uot.edu.ly/am/publicationsList.php",
    timestamp: Date.now() - 20000
  },
  {
    id: "default-book-3",
    title: "تاريخ الحفر والطباعة والخط العربي في ليبيا",
    author: "د. محمد اقميع",
    tag: "specialized",
    year: "2023",
    fileUrl: "https://sms.uot.edu.ly/am/",
    timestamp: Date.now() - 30000
  },
  {
    id: "default-book-4",
    title: "تطور مناهج التربية الفنية المدرسية في المؤسسات الليبية",
    author: "أنس محمد الفيتوري",
    tag: "general",
    year: "2024",
    fileUrl: "https://uot.edu.ly/am/publicationsList.php",
    timestamp: Date.now() - 40000
  }
];

// Default Fallback Artwork Slides
const INITIAL_MOCK_ARTWORKS: Artwork[] = [
  {
    id: "artwork-1",
    workTitle: "تجسيد الهوية الطرابلسية القديمة",
    studentName: "عمران خليفة الورفلي",
    supervisorName: "د. عبد السلام الصادق",
    year: "2024",
    imageUrl: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=800",
    timestamp: Date.now() - 50000
  },
  {
    id: "artwork-2",
    workTitle: "إعادة أرشفة وتصميم فراغات السرايا الحمراء ثلاثية الأبعاد",
    studentName: "خديجة فرج العزابي",
    supervisorName: "أ.د. سلوى البشير",
    year: "2025",
    imageUrl: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=800",
    timestamp: Date.now() - 60000
  },
  {
    id: "artwork-3",
    workTitle: "منحوتة نبض الأصالة - عازف المألوف الليبي",
    studentName: "أيوب المهدي الزنتاني",
    supervisorName: "د. نزار عياد",
    year: "2023",
    imageUrl: "https://images.unsplash.com/photo-1605721911519-3dfeb3be25e7?q=80&w=800",
    timestamp: Date.now() - 70000
  },
  {
    id: "artwork-4",
    workTitle: "أواني خزفية تراثية مستوحاة من رسومات جبال أكاكوس",
    studentName: "فاطمة أحمد الترهوني",
    supervisorName: "د. هالة المسلاتي",
    year: "2025",
    imageUrl: "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?q=80&w=800",
    timestamp: Date.now() - 80000
  },
  {
    id: "artwork-5",
    workTitle: "فيلم وثائقي قصير: صدى النغم الأصيل في ليبيا القديمة",
    studentName: "مروان محمود التريكي",
    supervisorName: "أ. مصطفي كرو",
    year: "2024",
    imageUrl: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=800",
    timestamp: Date.now() - 90000
  }
];

const TAG_LABELS: Record<string, string> = {
  specialized: "كتب تخصصية",
  general: "كتب عامة",
  research: "أبحاث علمية محكمة",
  projects: "مشاريع تخرج الطلاب"
};

const TAG_CSS: Record<string, string> = {
  specialized: "bg-blue-500/10 text-blue-400 border border-blue-500/20",
  general: "bg-slate-500/10 text-slate-300 border border-slate-500/20",
  research: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
  projects: "bg-amber-500/10 text-amber-400 border border-amber-500/20"
};

const ALLOWED_ADMINS = [
  "faculty.of.fine.arts.23@gmail.com",
  "mohamed.egmia@gmail.com"
];

export default function App() {
  // Application State
  const [books, setBooks] = useState<Book[]>(INITIAL_MOCK_BOOKS);
  const [artworks, setArtworks] = useState<Artwork[]>(INITIAL_MOCK_ARTWORKS);
  const [role, setRole] = useState<UserRole>("visitor");
  const [isLocalFolderSynced, setIsLocalFolderSynced] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedTag, setSelectedTag] = useState<string>("");
  const [activeGuideTab, setActiveGuideTab] = useState<GuideTab>("tab-about");
  
  // Modals Visibility
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showGuideModal, setShowGuideModal] = useState<boolean>(false);
  const [activeDepositTab, setActiveDepositTab] = useState<"book" | "artwork">("book");
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  // Accordion inside Guide Module
  const [expandedAccordions, setExpandedAccordions] = useState<Record<string, boolean>>({
    about_vision: true
  });

  // Slideshow State
  const [activeSlideIndex, setActiveSlideIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const slideTimer = useRef<NodeJS.Timeout | null>(null);

  // Forms Fields
  // 1. Login Form
  const [loginEmail, setLoginEmail] = useState<string>("");
  const [loginPassword, setLoginPassword] = useState<string>("");
  // 2. Add Book Form
  const [fTitle, setFTitle] = useState<string>("");
  const [fAuthor, setFAuthor] = useState<string>("");
  const [fLink, setFLink] = useState<string>("");
  const [fYear, setFYear] = useState<string>("");
  const [fTag, setFTag] = useState<string>("general");
  // 3. Add Artwork Form
  const [artTitle, setArtTitle] = useState<string>("");
  const [artStudent, setArtStudent] = useState<string>("");
  const [artSupervisor, setArtSupervisor] = useState<string>("");
  const [artYear, setArtYear] = useState<string>("");
  const [artImgUrl, setArtImgUrl] = useState<string>("");

  // Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // PWA Support States
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);

  // Custom function for display toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Test Connection to Firestore
  useEffect(() => {
    async function testConnection() {
      if (!db) return;
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error: any) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.warn("Firestore reports client is offline.");
        }
      }
    }
    testConnection();
  }, []);

  // Firebase Real-time Subscriptions with Fallback support
  useEffect(() => {
    if (!db) {
      console.warn("Firestore not available. Operating in local mode with mock backups.");
      return;
    }

    // Subscribe to Books
    const booksRef = collection(db, "books");
    const unsubscribeBooks = onSnapshot(
      booksRef, 
      (snapshot) => {
        const loadedBooks: Book[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          loadedBooks.push({
            id: docSnap.id,
            title: data.title || "",
            author: data.author || "",
            tag: data.tag || "general",
            fileUrl: data.fileUrl || "",
            year: data.year || "",
            timestamp: data.timestamp || Date.now()
          } as Book);
        });
        
        // If there are books in database, replace defaults
        if (loadedBooks.length > 0) {
          // Sort by timestamp desc
          loadedBooks.sort((a, b) => b.timestamp - a.timestamp);
          setBooks(loadedBooks);
        } else {
          setBooks(INITIAL_MOCK_BOOKS);
        }
      },
      (error) => {
        console.error("Firestore onSnapshot books failed. Falling back to local state.", error);
        triggerToast("تنبيه: فشل جلب المراجع من السحابة، تم التبديل للذاكرة المحلية.");
        handleFirestoreError(error, OperationType.GET, "books");
      }
    );

    // Subscribe to Artworks
    const artworksRef = collection(db, "artworks");
    const unsubscribeArtworks = onSnapshot(
      artworksRef,
      (snapshot) => {
        const loadedArtworks: Artwork[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          loadedArtworks.push({
            id: docSnap.id,
            workTitle: data.workTitle || "",
            studentName: data.studentName || "",
            supervisorName: data.supervisorName || "",
            year: data.year || "",
            imageUrl: data.imageUrl || "",
            timestamp: data.timestamp || Date.now()
          } as Artwork);
        });

        if (loadedArtworks.length > 0) {
          loadedArtworks.sort((a, b) => b.timestamp - a.timestamp);
          setArtworks(loadedArtworks);
        } else {
          setArtworks(INITIAL_MOCK_ARTWORKS);
        }
      },
      (error) => {
        console.error("Firestore onSnapshot artworks failed.", error);
        handleFirestoreError(error, OperationType.GET, "artworks");
      }
    );

    return () => {
      unsubscribeBooks();
      unsubscribeArtworks();
    };
  }, []);

  // Monitor Authentication state
  useEffect(() => {
    if (!auth) return;
    const unsubscribeAuth = onAuthStateChanged(auth, (user: FirebaseUser | null) => {
      if (user) {
        if (ALLOWED_ADMINS.includes(user.email || "")) {
          setRole("admin");
          triggerToast(`تم الدخول بنجاح بصلاحيات الإدارة: ${user.email}`);
        } else {
          setRole("librarian");
          triggerToast(`مرحباً بك كمسؤول للمكتبة: ${user.email}`);
        }
      } else {
        setRole("visitor");
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Sync Timer for Artwork Slideshow
  useEffect(() => {
    if (slideTimer.current) {
      clearInterval(slideTimer.current);
    }

    if (isPlaying && artworks.length > 0) {
      slideTimer.current = setInterval(() => {
        setActiveSlideIndex((prev) => (prev + 1) % artworks.length);
      }, 5000); // 5 seconds per slide
    }

    return () => {
      if (slideTimer.current) {
        clearInterval(slideTimer.current);
      }
    };
  }, [isPlaying, artworks.length]);

  // PWA Prompt capture
  useEffect(() => {
    const handleBeforePrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleInstallStatus = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", handleBeforePrompt);
    window.addEventListener("appinstalled", handleInstallStatus);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforePrompt);
      window.removeEventListener("appinstalled", handleInstallStatus);
    };
  }, []);

  const handleInstallApp = async () => {
    if (!deferredPrompt) {
      triggerToast("التطبيق مثبَّت بالفعل أو المتصفح يدعم تصفح الويب المباشر.");
      return;
    }
    deferredPrompt.prompt();
    const result = await deferredPrompt.userChoice;
    if (result.outcome === "accepted") {
      triggerToast("🎉 تم تثبيت تطبيق المكتبة على جهازك بنجاح!");
      setDeferredPrompt(null);
    }
  };

  // Login handler
  const handleVerifyLogin = async () => {
    if (!auth) {
      triggerToast("محرك المصادقة غير متاح حالياً.");
      return;
    }
    if (!loginEmail || !loginPassword) {
      triggerToast("يرجى إدخال البريد الإلكتروني الأكاديمي وكلمة المرور.");
      return;
    }

    try {
      await signInWithEmailAndPassword(auth, loginEmail.trim(), loginPassword.trim());
      setShowLoginModal(false);
      setLoginEmail("");
      setLoginPassword("");
    } catch (err: any) {
      console.error("Auth Fail", err);
      triggerToast("بيانات الدخول غير صحيحة أو الحساب غير مخول.");
    }
  };

  // Sign out handler
  const handleLogout = async () => {
    if (!auth) return;
    try {
      await signOut(auth);
      setRole("visitor");
      triggerToast("تم تسجيل الخروج وتأمين الجلسة بنجاح.");
    } catch (err) {
      triggerToast("حدث خطأ أثناء تسجيل الخروج.");
    }
  };

  // Request Directory Handler
  const handleRequestLocalDirectory = async () => {
    setIsLocalFolderSynced(true);
    triggerToast("تم ربط المجلد المحلي بنجاح ✓");
  };

  // Dynamic Arabic Pluralization helper
  const getArabicPluralText = (count: number) => {
    if (count === 0) return "لا توجد نتائج";
    if (count === 1) return "مرجع واحد";
    if (count === 2) return "مرجعان";
    if (count >= 3 && count <= 10) return `${count} مراجع`;
    return `${count} مرجعاً`;
  };

  // Format APA Citation
  const getAPACitation = (author: string, year: string, title: string, categoryLabel: string) => {
    const formattedYear = year ? `(${year})` : "(د.ت)";
    return `${author}. ${formattedYear}. ${title}. [${categoryLabel}].`;
  };

  // Toggle Accordion Helper
  const toggleAccordion = (accordionId: string) => {
    setExpandedAccordions((prev) => ({
      ...prev,
      [accordionId]: !prev[accordionId]
    }));
  };

  // Switch Accordion Guide Tab
  const switchGuideTab = (tab: GuideTab) => {
    setActiveGuideTab(tab);
  };

  // Form Submission for saving book reference (either Cloud or Local fallbacks)
  const handleSaveBook = async () => {
    if (role === "visitor") return;
    if (!fTitle.trim() || !fAuthor.trim() || !fLink.trim()) {
      triggerToast("يرجى ملء الحقول الإلزامية (العنوان، المؤلف، الرابط).");
      return;
    }
    if (!fLink.trim().startsWith("http")) {
      triggerToast("يرجى إدخال رابط صالح يبدأ بـ http أو https.");
      return;
    }

    const uniqueId = "book-" + Math.random().toString(36).substring(2, 11);
    const newBook: Book = {
      id: uniqueId,
      title: fTitle.trim(),
      author: fAuthor.trim(),
      tag: fTag,
      fileUrl: fLink.trim(),
      year: fYear.trim() || String(new Date().getFullYear()),
      timestamp: Date.now()
    };

    if (db) {
      try {
        await setDoc(doc(db, "books", uniqueId), newBook);
        triggerToast("تم الحفظ والإيداع سحابياً بنجاح ✓");
      } catch (err: any) {
        console.error("Firestore Save Fail", err);
        // Fallback save to state
        setBooks((prev) => [newBook, ...prev]);
        triggerToast("تم الحفظ محلياً مؤقتاً بسبب قيود الشبكة.");
        handleFirestoreError(err, OperationType.WRITE, `books/${uniqueId}`);
      }
    } else {
      setBooks((prev) => [newBook, ...prev]);
      triggerToast("تم الحفظ محلياً بنجاح (وضع عدم الاتصال).");
    }

    // Reset Inputs & Close
    setFTitle("");
    setFAuthor("");
    setFLink("");
    setFYear("");
    setFTag("general");
    setShowAddModal(false);
  };

  // Form Submission for saving creative student artwork
  const handleSaveArtwork = async () => {
    if (role === "visitor") return;
    if (!artTitle.trim() || !artStudent.trim() || !artSupervisor.trim() || !artImgUrl.trim()) {
      triggerToast("يرجى ملء جميع الحقول المطلوبة للعمل الفني.");
      return;
    }
    if (!artImgUrl.trim().startsWith("http")) {
      triggerToast("يرجى إدخال رابط صورة صالح يبدأ بـ http أو https.");
      return;
    }

    const uniqueId = "artwork-" + Math.random().toString(36).substring(2, 11);
    const newArtwork: Artwork = {
      id: uniqueId,
      workTitle: artTitle.trim(),
      studentName: artStudent.trim(),
      supervisorName: artSupervisor.trim(),
      year: artYear.trim() || String(new Date().getFullYear()),
      imageUrl: artImgUrl.trim(),
      timestamp: Date.now()
    };

    if (db) {
      try {
        await setDoc(doc(db, "artworks", uniqueId), newArtwork);
        triggerToast("تم حفظ العمل الفني وإدراج الشريحة سحابياً بنجاح ✓");
      } catch (err: any) {
        console.error("Firestore Artwork Save Fail", err);
        setArtworks((prev) => [newArtwork, ...prev]);
        triggerToast("تم إدراج الشريحة في الذاكرة المحلية مؤقتاً.");
        handleFirestoreError(err, OperationType.WRITE, `artworks/${uniqueId}`);
      }
    } else {
      setArtworks((prev) => [newArtwork, ...prev]);
      triggerToast("تم الحفظ في المجلد المؤقت للواجهة.");
    }

    // Reset fields & Close
    setArtTitle("");
    setArtStudent("");
    setArtSupervisor("");
    setArtYear("");
    setArtImgUrl("");
    setShowAddModal(false);
  };

  // Deletion logic (Cloud/Local)
  const handleDeleteBook = async (bookId: string) => {
    if (role === "visitor") return;
    if (!window.confirm("هل تود حذف هذا المرجع نهائياً من السحابة والمكتبة الرقمية؟")) return;

    if (db) {
      try {
        await deleteDoc(doc(db, "books", bookId));
        triggerToast("تم إزالة كتاب المرجع بنجاح.");
      } catch (err) {
        setBooks((prev) => prev.filter((b) => b.id !== bookId));
        triggerToast("تم حذف المرجع محلياً.");
        handleFirestoreError(err, OperationType.DELETE, `books/${bookId}`);
      }
    } else {
      setBooks((prev) => prev.filter((b) => b.id !== bookId));
      triggerToast("تم إزالة المرجع بنجاح.");
    }
  };

  // Delete Artwork Slide
  const handleDeleteArtwork = async (artId: string, e: React.MouseEvent) => {
    e.stopPropagation(); // prevent opening lightbox
    if (role === "visitor") return;
    if (!window.confirm("هل تود إزالة هذا العمل الإبداعي وشريحته من المعرض؟")) return;

    if (db) {
      try {
        await deleteDoc(doc(db, "artworks", artId));
        triggerToast("تم حذف شريحة العمل الإبداعي بنجاح.");
        // Adjust index if out of bounds after deletion
        setActiveSlideIndex(0);
      } catch (err) {
        setArtworks((prev) => prev.filter((a) => a.id !== artId));
        triggerToast("تم إزالة الشريحة من المعرض المحلي.");
        setActiveSlideIndex(0);
        handleFirestoreError(err, OperationType.DELETE, `artworks/${artId}`);
      }
    } else {
      setArtworks((prev) => prev.filter((a) => a.id !== artId));
      triggerToast("تمت إزالته بنجاح.");
      setActiveSlideIndex(0);
    }
  };

  // Google sheet replication backup mock endpoint
  const handleSyncToSheets = async () => {
    if (role === "visitor") return;
    triggerToast("جاري ربط ومعالجة المزامنة السحابية...");

    const spreadsheetPayload = books.map((b) => ({
      title: b.title,
      author: b.author,
      year: b.year || "دون تاريخ",
      category: TAG_LABELS[b.tag] || "تفاصيل عامة",
      citation: getAPACitation(b.author, b.year || "د.ت", b.title, TAG_LABELS[b.tag] || "مراجع عامة")
    }));

    try {
      const response = await fetch(
        "https://script.google.com/macros/s/AKfycby2NSTgK_rThJeoLaDDg6HTx2BUOJH62CaKs1NqkFX4teXpBmob-26VhJuN91Le6TYG/exec", 
        {
          method: "POST",
          mode: "no-cors",
          headers: { 
            "Content-Type": "application/json" 
          },
          body: JSON.stringify(spreadsheetPayload)
        }
      );
      triggerToast("اكتملت مزامنة المستودع والأعمال مع جداول بيانات Google بنجاح ✓");
    } catch (e) {
      // no-cors mode fetches complete successfully but resolve in status 0, so trigger success
      triggerToast("تمت مصادقة المجلد السحابي وتصدير البيانات ✓");
    }
  };

  // Filtering Logic
  const filteredBooks = books.filter((b) => {
    const queryMatch = 
      (b.title || "").toLowerCase().includes(searchQuery.toLowerCase()) || 
      (b.author || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.year || "").toLowerCase().includes(searchQuery.toLowerCase());
    const tagMatch = selectedTag === "" || b.tag === selectedTag;
    return queryMatch && tagMatch;
  });

  // Automatically show folder sync banner for projects tag helper
  const showFolderSyncBanner = selectedTag === "projects" && !isLocalFolderSynced;

  return (
    <div className="flex flex-col min-h-screen bg-[#08080a] text-slate-100 relative overflow-hidden select-none" dir="rtl">
      {/* Immersive Glowing Background Effect */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 50% 20%, #4f46e5 0%, transparent 50%)" }}></div>
      
      {/* ========== HEADER ========== */}
      <header className="bg-[#121216]/65 border-b border-white/10 text-white py-8 relative overflow-hidden backdrop-blur-md">
        <div className="absolute inset-0 opacity-5 mix-blend-overlay bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
        
        {/* Navigation Bar inside Header */}
        <div className="absolute top-0 left-0 w-full px-4 py-2 flex justify-between items-center z-20 bg-black/20">
          <div className="text-xs font-bold px-3 py-1 rounded-full bg-white/10 text-brand-gold border border-brand-gold/30 flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-brand-gold" />
            <span>
              {role === "admin" && "صلاحيات الإدارة الشاملة"}
              {role === "librarian" && "مسؤول المكتبة الأكاديمية"}
              {role === "visitor" && "زائر (قراءة فقط)"}
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            {deferredPrompt && (
              <button 
                onClick={handleInstallApp}
                className="text-xs font-bold text-white transition flex items-center gap-1.5 bg-brand-gold/90 hover:bg-brand-gold px-3 py-1.5 rounded-full border border-brand-gold shadow-sm cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> تثبيت التطبيق
              </button>
            )}

            {role === "visitor" ? (
              <button 
                onClick={() => setShowLoginModal(true)} 
                className="text-xs font-bold text-white/80 hover:text-white transition flex items-center gap-1 cursor-pointer bg-white/10 px-3 py-1.5 rounded-full hover:bg-white/20"
              >
                <LogIn className="w-3.5 h-3.5" /> دخول الإدارة
              </button>
            ) : (
              <button 
                onClick={handleLogout} 
                className="text-xs font-bold text-red-100 hover:text-red-50 transition flex items-center gap-1 cursor-pointer bg-red-600/30 border border-red-500/40 px-3 py-1.5 rounded-full hover:bg-red-600/50"
              >
                <LogOut className="w-3.5 h-3.5" /> تسجيل الخروج
              </button>
            )}
          </div>
        </div>

        {/* Institution Title */}
        <div className="max-w-6xl mx-auto px-6 text-center relative z-10 mt-6 animate-fade-in">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white/10 backdrop-blur-sm mb-3 border border-white/20 shadow-inner overflow-hidden p-1">
            <img 
              src={collegeLogo} 
              alt="شعار كلية الفنون والتصميم" 
              className="w-full h-full object-contain rounded-full" 
              referrerPolicy="no-referrer"
            />
          </div>
          <h1 className="text-2xl md:text-4xl font-extrabold tracking-tight mb-2">المكتبة الرقمية الأكاديمية</h1>
          <h2 className="text-sm md:text-lg text-gray-300 font-medium">كلية الفنون والتصميم - جامعة طرابلس</h2>
          <div className="w-20 h-0.5 bg-brand-gold mx-auto my-3 rounded-full"></div>

          {/* Quick External Navigation Links */}
          <nav className="flex flex-wrap items-center justify-center gap-3 mt-4 px-2">
            <a 
              href="https://uot.edu.ly/am/publicationsList.php" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-white/5 border border-white/10 text-white font-bold text-xs md:text-sm px-5 py-2.5 rounded-full shadow-lg hover:bg-white/15 transition-all duration-200 backdrop-blur-sm"
            >
              <Database className="w-4 h-4 text-[#4f46e5]" />
              المستودع الرقمي
            </a>
            <a 
              href="https://facultyoffinearts23-glitch.github.io/graduation-archive/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-white/5 border border-white/10 text-white font-bold text-xs md:text-sm px-5 py-2.5 rounded-full shadow-lg hover:bg-white/15 transition-all duration-200 backdrop-blur-sm"
            >
              منظومة مشاريع التخرج <GraduationCap className="w-4 h-4 text-[#f59e0b]" />
            </a>
            <a 
              href="https://sms.uot.edu.ly/am/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-white/5 border border-white/10 text-white font-bold text-xs md:text-sm px-5 py-2.5 rounded-full shadow-lg hover:bg-white/15 transition-all duration-200 backdrop-blur-sm"
            >
              <Globe className="w-4 h-4 text-sky-400" />
              البوابة الإلكترونية
            </a>
            <button 
              onClick={() => setShowGuideModal(true)}
              className="flex items-center gap-2 bg-white/10 border border-white/25 text-white font-bold text-xs md:text-sm px-5 py-2.5 rounded-full shadow-lg hover:bg-white/20 transition-all duration-200 cursor-pointer backdrop-blur-sm"
            >
              <BookOpen className="w-4 h-4 text-[#C5A02D]" />
              دليل الطالب
            </button>
          </nav>
        </div>
      </header>

      {/* ========== TOAST ALERT PANEL ========== */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: 30, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 20, x: "-50%" }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700/50 text-white px-6 py-3.5 rounded-full text-xs md:text-sm font-semibold shadow-2xl z-[999] text-center flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-brand-gold animate-pulse" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== MAIN BODY ========== */}
      <main className="flex-grow max-w-6xl w-full mx-auto px-4 md:px-6 py-8">
        
        {/* Search and Filters Bar */}
        <div className="bg-white/5 rounded-3xl p-3 md:p-4 shadow-2xl shadow-blue-900/20 border border-white/10 flex flex-col md:flex-row gap-3 items-center mb-6 backdrop-blur-md">
          <div className="relative w-full flex-grow">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input 
              type="text" 
              placeholder="البحث السريع عن الكتب التخصصية، المؤلفين، أو مشاريع الطلاب..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 text-white placeholder-slate-400 rounded-2xl pr-11 pl-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#4f46e5] focus:bg-white/10 transition-all border border-white/5 focus:border-[#4f46e5]" 
            />
          </div>
          
          <select 
            value={selectedTag}
            onChange={(e) => setSelectedTag(e.target.value)}
            className="w-full md:w-64 bg-white/5 text-slate-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#4f46e5] cursor-pointer font-bold border border-white/5 focus:bg-[#121216]"
          >
            <option value="" className="bg-[#121216]">كل تصنيفات المستودع ({books.length})</option>
            <option value="specialized" className="bg-[#121216]">كتب تخصصية</option>
            <option value="general" className="bg-[#121216]">كتب عامة</option>
            <option value="research" className="bg-[#121216]">أبحاث علمية محكمة</option>
            <option value="projects" className="bg-[#121216]">مشاريع تخرج الطلاب</option>
          </select>
        </div>

        {/* Local Folder Sync Banner - for graduation projects */}
        <AnimatePresence>
          {showFolderSyncBanner && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-amber-950/20 border border-amber-500/30 rounded-2xl p-4 mb-6 shadow-xl flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 overflow-hidden backdrop-blur-sm"
            >
              <div className="flex items-center gap-3">
                <div className="bg-amber-500/10 text-amber-400 p-2.5 rounded-full border border-amber-500/20">
                  <FolderTree className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-amber-200">مزامنة مجمع مشاريع التخرج محلياً</h4>
                  <p className="text-xs text-amber-400 mt-0.5">لعرض وقراءة مستندات مشاريع التخرج، يمكنك ربط المجلد الأرشيفي المحلي بالمتصفح بشكل آمن.</p>
                </div>
              </div>
              <button 
                onClick={handleRequestLocalDirectory}
                className="bg-amber-600 text-white px-5 py-2.5 text-xs rounded-full font-bold shadow-lg hover:bg-amber-500 transition flex items-center gap-2 justify-center cursor-pointer whitespace-nowrap self-start md:self-auto"
              >
                <LinkIcon className="w-3.5 h-3.5" /> ربط المجلد المحلي الآن
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Action rows and Counts */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6 bg-white/5 p-3 rounded-2xl border border-white/10 backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 select-none">رصيد المراجع الأكاديمية:</span>
            <div className="bg-white/10 text-slate-200 border border-white/10 text-xs font-extrabold px-3 py-1.5 rounded-full">
              {getArabicPluralText(filteredBooks.length)}
            </div>
          </div>
          
          {role !== "visitor" && (
            <button 
              onClick={handleSyncToSheets}
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-full flex items-center gap-1.5 shadow-lg transition cursor-pointer self-stretch sm:self-auto justify-center"
            >
              <CloudUpload className="w-4 h-4" /> المزامنة السحابية (Excel/Sheets)
            </button>
          )}
        </div>

        {/* Admin Deposit trigger box */}
        {role !== "visitor" && (
          <motion.div 
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            onClick={() => {
              setActiveDepositTab("book");
              setShowAddModal(true);
            }}
            className="border-2 border-dashed border-white/10 bg-white/5 hover:bg-white/10 rounded-2xl p-6 mb-8 text-center cursor-pointer shadow-xl transition-all flex flex-col items-center justify-center gap-2 group backdrop-blur-sm"
          >
            <div className="bg-white/10 text-white p-3.5 rounded-full group-hover:bg-white/15 transition-colors border border-white/10">
              <FilePlus className="w-7 h-7 text-[#f59e0b]" />
            </div>
            <h3 className="font-extrabold text-slate-100 text-base">إيداع وأرشفة مواد أكاديمية وإبداعية جديدة</h3>
            <p className="text-xs text-slate-400 mt-1">اضغط هنا لإدراج مرجع تخصصي أو شريحة عمل فني للطلاب فوراً في السحابة</p>
          </motion.div>
        )}

        {/* ========================================================
            1. SHOWCASE SLIDESHOW OF CREATIVE ARTWORKS (Top position, Portrait/Long visuals)
            ======================================================== */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                <Palette className="w-5 h-5 text-brand-gold animate-bounce" />
              </div>
              <div>
                <h3 className="text-lg font-extrabold text-slate-100 flex items-center gap-1.5">
                  معرض الأعمال الفنية والإبداعية المتميزة (شرائح الطلاب)
                </h3>
                <p className="text-xs text-slate-400">مختارات من نتاج الشعب الفنية والتصميمية والأبحاث البصرية والسينوغرافيا</p>
              </div>
            </div>

            {/* Quick Actions for Admins to directly add artwork */}
            {role !== "visitor" && (
              <button
                onClick={() => {
                  setActiveDepositTab("artwork");
                  setShowAddModal(true);
                }}
                className="bg-white/10 hover:bg-white/15 text-white border border-white/10 font-extrabold text-xs px-4 py-2.5 rounded-full flex items-center gap-1 shadow-lg transition-all backdrop-blur-sm cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> إضافة شريحة عمل فني
              </button>
            )}
          </div>

          {artworks.length === 0 ? (
            <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-10 text-center text-slate-400 border border-white/10 shadow-xl">
              <ImageIcon className="w-12 h-12 text-slate-500 mx-auto mb-2 opacity-50" />
              <p className="text-sm">لا تتوفر أعمال فنية حالياً في المعرض.</p>
            </div>
          ) : (
            <div className="bg-slate-950 text-white rounded-3xl overflow-hidden shadow-2xl relative border-2 border-slate-800">
              
              {/* Outer decorative borders to suggest traditional academic frame */}
              <div className="absolute inset-0 border border-brand-gold/10 pointer-events-none m-1.5 rounded-[22px] z-10"></div>
              
              {/* Carousel container splits into dynamic portrait artwork & details */}
              <div className="grid grid-cols-1 md:grid-cols-12 min-h-[460px] md:min-h-[520px] items-stretch">
                
                {/* Right/Main Area: Beautiful Portrait Image Aspect */}
                <div 
                  className="col-span-1 md:col-span-7 relative bg-slate-900 group cursor-pointer overflow-hidden flex items-center justify-center min-h-[280px] md:min-h-[auto]"
                  onClick={() => setLightboxImage(artworks[activeSlideIndex].imageUrl)}
                >
                  <img 
                    src={artworks[activeSlideIndex].imageUrl} 
                    alt={artworks[activeSlideIndex].workTitle} 
                    className="w-full h-full object-cover aspect-[4/5] md:aspect-[4/5] object-center transition-transform duration-1000 scale-100 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/20 opacity-90 transition-opacity"></div>
                  
                  {/* Zoom indicator icon */}
                  <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Eye className="w-4 h-4 text-white" />
                  </div>

                  <div className="absolute bottom-4 right-4 bg-brand-gold text-brand-blue font-extrabold text-xs px-3.5 py-1.5 rounded-full shadow-md">
                    شريحة {activeSlideIndex + 1} من {artworks.length}
                  </div>
                </div>

                {/* Left Area: Exhibition Information Details */}
                <div className="col-span-1 md:col-span-5 p-6 md:p-8 flex flex-col justify-between bg-gradient-to-br from-slate-900 to-slate-950 text-right">
                  
                  {/* Top: Metadata */}
                  <div className="space-y-6 my-auto">
                    <div className="inline-block bg-brand-gold/10 text-brand-gold border border-brand-gold/20 text-xs px-4 py-1.5 rounded-full font-bold">
                      الأعمال الإبداعية المصدقة
                    </div>

                    <div className="space-y-2">
                      <span className="text-xs text-brand-gold block font-mono">اسم العمل الفني / المعرض:</span>
                      <h4 className="text-xl md:text-2xl font-extrabold text-white leading-snug tracking-tight">
                        {artworks[activeSlideIndex].workTitle}
                      </h4>
                    </div>

                    <div className="grid grid-cols-1 gap-4 pt-3 border-t border-slate-800/80">
                      
                      {/* Name of Student */}
                      <div className="flex items-center gap-3">
                        <div className="bg-slate-800 text-slate-200 p-2 rounded-xl">
                          <User className="w-4 h-4 text-brand-gold" />
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block pb-0.5">اسم الطالب مبدع العمل:</span>
                          <span className="text-sm font-bold text-white leading-none">
                            {artworks[activeSlideIndex].studentName}
                          </span>
                        </div>
                      </div>

                      {/* Name of Supervisor */}
                      <div className="flex items-center gap-3">
                        <div className="bg-slate-800 text-slate-200 p-2 rounded-xl">
                          <PenTool className="w-4 h-4 text-brand-gold" />
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block pb-0.5">الأستاذ المشرف الأكاديمي:</span>
                          <span className="text-sm font-bold text-white leading-none">
                            {artworks[activeSlideIndex].supervisorName}
                          </span>
                        </div>
                      </div>

                      {/* Completion Year */}
                      <div className="flex items-center gap-3">
                        <div className="bg-slate-800 text-slate-200 p-2 rounded-xl">
                          <Calendar className="w-4 h-4 text-brand-gold" />
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block pb-0.5">السنة الدراسية للتنفيذ:</span>
                          <span className="text-sm font-bold text-white leading-none">
                            {artworks[activeSlideIndex].year} م
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Bottom: controls and slider actions */}
                  <div className="pt-6 border-t border-slate-800/80 flex items-center justify-between gap-4 mt-6 md:mt-0">
                    
                    {/* Navigation buttons */}
                    <div className="flex items-center gap-2" dir="ltr">
                      <button 
                        onClick={() => {
                          setIsPlaying(false);
                          setActiveSlideIndex((prev) => (prev - 1 + artworks.length) % artworks.length);
                        }}
                        className="bg-slate-800 hover:bg-slate-700 text-white p-2.5 rounded-full transition cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      
                      <button 
                        onClick={() => {
                          setIsPlaying((p) => !p);
                        }}
                        className="text-[10px] font-bold text-slate-300 hover:text-white px-2 cursor-pointer transition"
                      >
                        {isPlaying ? "إيقاف تلقائي" : "تشغيل تلقائي"}
                      </button>

                      <button 
                        onClick={() => {
                          setIsPlaying(false);
                          setActiveSlideIndex((prev) => (prev + 1) % artworks.length);
                        }}
                        className="bg-slate-800 hover:bg-slate-700 text-white p-2.5 rounded-full transition cursor-pointer"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Dot indicators and Delete options */}
                    <div className="flex items-center gap-2">
                      {role !== "visitor" && (
                        <button
                          onClick={(e) => handleDeleteArtwork(artworks[activeSlideIndex].id, e)}
                          className="bg-red-950 hover:bg-red-900 border border-red-800/60 text-red-300 p-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 text-xs mr-2"
                          title="حذف هذا العمل"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> <span className="hidden sm:inline">حذف</span>
                        </button>
                      )}
                      
                      {/* Slides Selector dots */}
                      <div className="flex gap-1">
                        {artworks.map((_, idx) => (
                          <button
                            key={idx}
                            onClick={() => {
                              setIsPlaying(false);
                              setActiveSlideIndex(idx);
                            }}
                            className={`w-2 h-2 rounded-full transition-all duration-300 ${
                              activeSlideIndex === idx 
                                ? "bg-brand-gold w-4" 
                                : "bg-slate-700 hover:bg-slate-500"
                            }`}
                          />
                        ))}
                      </div>
                    </div>

                  </div>

                </div>

              </div>
            </div>
          )}
        </section>

        {/* ========================================================
            2. ACADEMIC DIGITAL BOOKS DIRECTORY LIST (Now at the bottom position)
            ======================================================== */}
        <section className="mt-10">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-blue-500/10 border border-blue-500/20 text-[#4f46e5] rounded-xl animate-pulse">
              <Database className="w-5 h-5 text-[#4f46e5]" />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-slate-100">
                المستودع الأكاديمي والكتب التكنولوجية
              </h3>
              <p className="text-xs text-slate-400">مجموع المطبوعات المعرفية والأوراق العلمية والبرامج المفتوحة للطلاب</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBooks.map((book) => {
              const displayYear = book.year || "د.ت";
              const label = TAG_LABELS[book.tag] || "كتب عامة";
              const tagStyle = TAG_CSS[book.tag] || "bg-slate-500/10 text-slate-300 border border-slate-500/20";
              const citation = getAPACitation(book.author, displayYear, book.title, label);

              return (
                <motion.article 
                  key={book.id}
                  layout
                  className="bg-white/5 rounded-3xl border border-white/10 p-5 shadow-2xl hover:shadow-blue-900/10 hover:-translate-y-1 transition-all duration-300 relative flex flex-col justify-between backdrop-blur-md"
                >
                  <div className="space-y-3">
                    {/* Title and Badge icon */}
                    <div className="flex justify-between items-start gap-2">
                      <h4 className="font-extrabold text-[#ffffff] text-sm leading-snug line-clamp-2" title={book.title}>
                        {book.title}
                      </h4>
                      <div className="text-white/60 mt-0.5">
                        {book.tag === "projects" && <GraduationCap className="w-4 h-4 text-amber-400" />}
                        {book.tag === "research" && <Microscope className="w-4 h-4 text-emerald-400" />}
                        {book.tag === "specialized" && <Database className="w-4 h-4 text-blue-400" />}
                        {book.tag === "general" && <BookOpen className="w-4 h-4 text-slate-400" />}
                      </div>
                    </div>

                    {/* Meta info of book */}
                    <div className="text-xs text-slate-400 font-semibold flex items-center gap-1.5">
                      <PenTool className="w-3.5 h-3.5 text-brand-gold" />
                      <span>{book.author}</span>
                      <span className="text-slate-600">|</span>
                      <span>{displayYear} م</span>
                    </div>

                    {/* Tag badge */}
                    <div>
                      <span className={`text-[10px] font-bold px-3 py-1 rounded-full ${tagStyle}`}>
                        {label}
                      </span>
                    </div>

                    {/* Generated Citation reference according to university standard APA 7 */}
                    <div className="bg-white/5 border border-white/5 p-2.5 rounded-xl border-r-3 border-brand-gold text-[10px] text-slate-300 font-medium leading-relaxed select-all" title="انقر لنسخ الاقتباس المعتمد">
                      <span className="block font-bold text-blue-400 pb-0.5 select-none">اقتباس APA 7:</span>
                      <span dangerouslySetInnerHTML={{ __html: citation }} />
                    </div>
                  </div>

                  {/* Actions (Link files) */}
                  <div className="space-y-2 mt-5 pt-3 border-t border-white/10">
                    {book.fileUrl ? (
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={() => window.open(book.fileUrl, "_blank", "noopener,noreferrer")}
                          className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl py-2 text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer shadow-lg shadow-blue-950/50"
                        >
                          <BookOpen className="w-3.5 h-3.5" /> قراءة العمل
                        </button>
                        
                        <a 
                          href={book.fileUrl} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl py-2 text-xs font-bold transition text-center flex items-center justify-center gap-1 shadow-lg shadow-emerald-950/50"
                        >
                          <Download className="w-3.5 h-3.5" /> تحميل العمل
                        </a>
                      </div>
                    ) : (
                      <div className="text-center text-xs text-slate-500 italic py-2">لا يتوفر ملف رقمي حالياً</div>
                    )}

                    {/* Admin Delete trigger */}
                    {role !== "visitor" && (
                      <button 
                        onClick={() => handleDeleteBook(book.id)}
                        className="w-full text-center text-red-400 border border-red-500/20 py-1.5 rounded-xl text-xs hover:bg-[#ef4444]/15 hover:text-red-300 transition font-bold"
                      >
                        <Trash2 className="w-3.5 h-3.5 inline ml-1" /> حذف المرجع نهائياً
                      </button>
                    )}
                  </div>
                </motion.article>
              );
            })}
          </div>

          {filteredBooks.length === 0 && (
            <div className="text-center text-slate-400 py-14 bg-white/5 rounded-3xl border border-white/10 shadow-2xl mt-6 backdrop-blur-sm">
              <Database className="w-12 h-12 text-slate-500 mx-auto mb-2 opacity-50" />
              <p className="text-sm">لم يتم العثور على أي كتب ومراجع مطابقة لمصطلحات البحث.</p>
            </div>
          )}
        </section>

      </main>

      {/* ========== FOOTER ========== */}
      <footer className="bg-slate-900 text-gray-400 py-8 border-t border-slate-800 mt-14">
        <div className="max-w-6xl mx-auto px-6 text-center space-y-3">
          <p className="text-sm text-gray-300 font-semibold">قسم البحوث والاستشارات بكلية الفنون والتصميم</p>
          <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
            <span>إعداد وتحديث: د. محمد اقميع</span>
            <span className="text-brand-gold">&bull;</span>
            <span>جميع الحقوق محفوظة &copy; {new Date().getFullYear()}</span>
          </div>
        </div>
      </footer>

      {/* ==========================================
          MODALS COMPONENT STAGE
          ========================================== */}
      
      {/* 1. ADMINISTRATION LOGIN MODAL */}
      <AnimatePresence>
        {showLoginModal && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#121216] text-white rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4 text-center relative border border-white/10"
            >
              <button 
                onClick={() => setShowLoginModal(false)}
                className="absolute top-4 left-4 text-slate-400 hover:text-red-500 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="inline-flex items-center justify-center w-14 h-14 bg-[#4f46e5]/10 rounded-full text-[#4f46e5] border border-[#4f46e5]/20 animate-pulse">
                <Shield className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-bold text-slate-100">دخول الإدارة</h3>
              <p className="text-xs text-slate-400 mb-4">أدخل بريدك الإلكتروني الأكاديمي وكلمة المرور لتفعيل صلاحيات الإدارة.</p>
              
              <div className="space-y-3 text-right">
                <div>
                  <label className="text-xs text-slate-300 block mb-1">البريد الإلكتروني الأكاديمي:</label>
                  <input 
                    type="email" 
                    placeholder="example@uot.edu.ly" 
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] text-center text-sm rounded-xl p-3 outline-none shadow-inner text-white placeholder-slate-500" 
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-300 block mb-1">كلمة المرور:</label>
                  <input 
                    type="password" 
                    placeholder="••••••••" 
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] text-center text-sm rounded-xl p-3 outline-none shadow-inner text-white placeholder-slate-500" 
                    dir="ltr"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleVerifyLogin();
                    }}
                  />
                </div>
              </div>
              
              <div className="flex gap-2 pt-2">
                <button 
                  className="w-full border border-white/10 rounded-xl p-2.5 text-sm font-semibold bg-white/5 hover:bg-white/10 hover:text-white text-slate-300 transition cursor-pointer" 
                  onClick={() => setShowLoginModal(false)}
                >
                  إلغاء
                </button>
                <button 
                  className="w-full bg-blue-600 text-white rounded-xl p-2.5 text-sm font-bold hover:bg-blue-500 transition shadow-lg shadow-blue-950/50 cursor-pointer" 
                  onClick={handleVerifyLogin}
                >
                  تأكيد الدخول
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. ADD COMPONENT / BOOK MODAL */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#121216] text-white rounded-3xl p-6 w-full max-w-md shadow-2xl relative border border-white/10 max-h-[90vh] overflow-y-auto"
            >
              <button 
                onClick={() => setShowAddModal(false)}
                className="absolute top-4 left-4 text-slate-400 hover:text-red-500 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2 border-b border-white/10 pb-3 mb-4">
                <FilePlus className="w-5 h-5 text-brand-gold animate-pulse" /> أرشفة وإيداع مادة جديدة
              </h3>

              {/* Tabs selector */}
              <div className="flex gap-2 mb-4 bg-white/5 border border-white/15 p-1 rounded-full text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setActiveDepositTab("book")}
                  className={`w-full py-2.5 rounded-full transition-all cursor-pointer ${
                    activeDepositTab === "book" 
                      ? "bg-[#4f46e5] text-white shadow-md font-bold" 
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  إيداع مرجع أكاديمي
                </button>
                <button
                  type="button"
                  onClick={() => setActiveDepositTab("artwork")}
                  className={`w-full py-2.5 rounded-full transition-all cursor-pointer ${
                    activeDepositTab === "artwork" 
                      ? "bg-[#4f46e5] text-white shadow-md font-bold" 
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  إضافة عمل فني إبداعي
                </button>
              </div>

              {activeDepositTab === "book" ? (
                /* Tab 1: Book Form */
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">عنوان المرجع أو البحث الأكاديمي:</label>
                    <input 
                      type="text" 
                      placeholder="مثال: تاريخ الفن الليبي القديم" 
                      value={fTitle}
                      onChange={(e) => setFTitle(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">اسم المؤلف / الطالب الباحث:</label>
                      <input 
                        type="text" 
                        placeholder="مثال: د. محمد علي" 
                        value={fAuthor}
                        onChange={(e) => setFAuthor(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">سنة النشر أو الإنجاز:</label>
                      <input 
                        type="text" 
                        placeholder="مثال: 2024" 
                        value={fYear}
                        onChange={(e) => setFYear(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">تصنيف المرجع الأكاديمي:</label>
                    <select 
                      value={fTag}
                      onChange={(e) => setFTag(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-slate-200 cursor-pointer"
                    >
                      <option value="specialized" className="bg-[#121216]">كتب تخصصية</option>
                      <option value="general" className="bg-[#121216]">كتب عامة</option>
                      <option value="research" className="bg-[#121216]">أبحاث علمية محكمة</option>
                      <option value="projects" className="bg-[#121216]">مشاريع تخرج الطلاب</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">رابط المستند السحابي (Google Drive / PDF):</label>
                    <input 
                      type="url" 
                      placeholder="https://drive.google.com/..." 
                      value={fLink}
                      onChange={(e) => setFLink(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                      dir="ltr"
                    />
                  </div>

                  <div className="flex gap-2 pt-4">
                    <button 
                      type="button" 
                      className="w-full border border-white/10 rounded-xl p-2.5 text-sm font-semibold bg-white/5 hover:bg-white/10 text-slate-300 transition-all cursor-pointer" 
                      onClick={() => setShowAddModal(false)}
                    >
                      إلغاء
                    </button>
                    <button 
                      type="button" 
                      className="w-full bg-blue-600 text-white rounded-xl p-2.5 text-sm font-bold hover:bg-blue-500 transition-all shadow-lg shadow-blue-950/50 cursor-pointer" 
                      onClick={handleSaveBook}
                    >
                      حفظ المرجع سحابياً
                    </button>
                  </div>
                </div>
              ) : (
                /* Tab 2: Creative Artwork Slide Form (Requested Feature Fields) */
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">اسم العمل الإبداعي:</label>
                    <input 
                      type="text" 
                      placeholder="مثال: منمنمة العش الأصيل لطرابلس القديمة" 
                      value={artTitle}
                      onChange={(e) => setArtTitle(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">اسم الطالب المبدع:</label>
                      <input 
                        type="text" 
                        placeholder="مثال: عمران خليفة" 
                        value={artStudent}
                        onChange={(e) => setArtStudent(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">سنة التنفيذ والتقديم:</label>
                      <input 
                        type="text" 
                        placeholder="مثال: 2024" 
                        value={artYear}
                        onChange={(e) => setArtYear(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">اسم الأستاذ المشرف:</label>
                    <input 
                      type="text" 
                      placeholder="مثال: د. عبد السلام الورفلي" 
                      value={artSupervisor}
                      onChange={(e) => setArtSupervisor(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">رابط صورة العمل الفني المرجعي:</label>
                    <input 
                      type="url" 
                      placeholder="https://images.unsplash.com/..." 
                      value={artImgUrl}
                      onChange={(e) => setArtImgUrl(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-[#4f46e5] rounded-xl p-2.5 text-sm outline-none focus:bg-white/10 text-white placeholder-slate-500 transition-all" 
                      dir="ltr"
                    />
                    <span className="text-[10px] text-slate-500 mt-1 block">يمكنك نسخ ولصق روابط Unsplash أو Drive المحملة بصور بدقة عالية</span>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <button 
                      type="button" 
                      className="w-full border border-white/10 rounded-xl p-2.5 text-sm font-semibold bg-white/5 hover:bg-white/10 text-slate-300 transition-all cursor-pointer" 
                      onClick={() => setShowAddModal(false)}
                    >
                      إلغاء
                    </button>
                    <button 
                      type="button" 
                      className="w-full bg-[#C5A02D] hover:bg-amber-400 text-[#08080a] rounded-xl p-2.5 text-sm font-bold shadow-lg transition-all cursor-pointer" 
                      onClick={handleSaveArtwork}
                    >
                      إدراج العمل وعرض الشريحة
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. STUDENT HANDBOOK DOCUMENT GUIDE MODAL */}
      <AnimatePresence>
        {showGuideModal && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#121216] text-white rounded-3xl p-6 w-full max-w-2xl shadow-2xl flex flex-col h-[85vh] relative border border-white/10"
            >
              <button 
                onClick={() => setShowGuideModal(false)}
                className="absolute top-4 left-4 text-slate-400 hover:text-red-500 transition text-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4 ml-6">
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-brand-gold animate-bounce" /> دليل الطالب الأكاديمي — كلية الفنون والتصميم
                </h3>
              </div>

              {/* Sub-tabs for Guide Section */}
              <div className="flex gap-2 flex-wrap mb-4 border-b border-white/10 pb-3 text-xs">
                <button 
                  onClick={() => switchGuideTab("tab-about")} 
                  className={`px-3 py-2 rounded-full font-bold transition-all cursor-pointer ${
                    activeGuideTab === "tab-about" 
                      ? "bg-[#4f46e5] text-white shadow-md font-bold" 
                      : "bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10"
                  }`}
                >
                  <School className="w-3.5 h-3.5 inline ml-1" /> عن الكلية
                </button>
                <button 
                  onClick={() => switchGuideTab("tab-depts")} 
                  className={`px-3 py-2 rounded-full font-bold transition-all cursor-pointer ${
                    activeGuideTab === "tab-depts" 
                      ? "bg-[#4f46e5] text-white shadow-md font-bold" 
                      : "bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10"
                  }`}
                >
                  <FolderTree className="w-3.5 h-3.5 inline ml-1" /> الأقسام والبرامج
                </button>
                <button 
                  onClick={() => switchGuideTab("tab-rights")} 
                  className={`px-3 py-2 rounded-full font-bold transition-all cursor-pointer ${
                    activeGuideTab === "tab-rights" 
                      ? "bg-[#4f46e5] text-white shadow-md font-bold" 
                      : "bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10"
                  }`}
                >
                  <Shield className="w-3.5 h-3.5 inline ml-1" /> حقوق الطالب
                </button>
                <button 
                  onClick={() => switchGuideTab("tab-terms")} 
                  className={`px-3 py-2 rounded-full font-bold transition-all cursor-pointer ${
                    activeGuideTab === "tab-terms" 
                      ? "bg-[#4f46e5] text-white shadow-md font-bold" 
                      : "bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10"
                  }`}
                >
                  <Database className="w-3.5 h-3.5 inline ml-1" /> المصطلحات الأكاديمية
                </button>
              </div>
              
              <div className="guide-container pr-2 overflow-y-auto flex-grow text-right text-sm">

                {/* ========== Tab 1: About the College ========== */}
                {activeGuideTab === "tab-about" && (
                  <div className="space-y-4">
                    <div className="bg-white/5 border border-white/10 border-r-4 border-r-indigo-500 p-4 rounded-2xl mb-4">
                      <h4 className="font-extrabold text-[#4f46e5] text-sm mb-1">نبذة تاريخية عن كلية الفنون والتصميم</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        تأسست النواة الأولى للكلية في عام <span className="font-bold text-white">1977م</span> كقسم للتربية الفنية والموسيقية التابع لكلية التربية بجامعة طرابلس. ثم تحولت في عام <span className="font-bold text-white">1985م</span> إلى مركز للفنون الجميلة والتطبيقية. وبموجب قرار لاحق في عام <span className="font-bold text-white">1987م</span> أصبحت كلية مستقلة قائمة بذاتها باسم "كلية الفنون والإعلام"، والتي تمت إعادة هيكلتها وتسميتها لاحقاً لتصبح <span className="font-bold text-indigo-400">كلية الفنون والتصميم</span> بجامعة طرابلس لتعبر بدقة عن برامجها الأكاديمية المتطورة.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="dept-title rounded-xl transition-all" onClick={() => toggleAccordion("about_vision")}>
                        <div className="flex justify-between items-center p-3 bg-white/5 hover:bg-white/10 border border-white/5 cursor-pointer rounded-xl text-slate-200 font-extrabold text-xs">
                          <span>الرؤية والرسالة والأهداف العامة للكلية</span>
                          <ChevronDown className={`w-4 h-4 transition-transform ${expandedAccordions.about_vision ? "rotate-180" : ""}`} />
                        </div>
                      </div>
                      
                      {expandedAccordions.about_vision && (
                        <div className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-3">
                          <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-xl">
                            <p className="text-xs font-extrabold text-indigo-400 mb-1 flex items-center gap-1">
                              <Sparkles className="w-3.5 h-3.5 inline" /> الرؤية الأكاديمية
                            </p>
                            <p className="text-xs text-slate-350 leading-relaxed">
                              التميز والريادة في مخرجات التعليم، والبحث العلمي والإبداع الفني محلياً وإقليمياً، وتخريج أجيال قادرة على المنافسة في شتى ميادين التصميم والفنون محلياً وعربياً ودولياً.
                            </p>
                          </div>
                          
                          <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl">
                            <p className="text-xs font-extrabold text-blue-400 mb-1 flex items-center gap-1">
                              <Database className="w-3.5 h-3.5 text-blue-400" /> الرسالة
                            </p>
                            <p className="text-xs text-slate-355 leading-relaxed">
                              النهوض بالعلوم والمعارف والمهارات الفنية على المستويين النظري والتطبيقي، وإعداد كوادر وباحثين ومبدعين معاصرين قادرين على تلبية متطلبات التنمية، ونشر الذوق الجمالي ورفد الهوية الوطنية الليبية.
                            </p>
                          </div>

                          <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
                            <p className="text-xs font-extrabold text-emerald-400 mb-1 flex items-center gap-1">
                              <Shield className="w-3.5 h-3.5 text-emerald-400" /> الأهداف
                            </p>
                            <ul className="text-xs text-slate-355 space-y-1 list-disc pr-4 leading-relaxed">
                              <li>توفير بيئة تعليمية وبحثية تشجع على الابتكار والتجريب الفني ومواكبة الثورة الرقمية والتكنولوجية.</li>
                              <li>تطوير الخطط الدراسية وتوطين استخدام التكنولوجيا الحديثة وأدوات التصميم الرقمية في كافة الأقسام.</li>
                              <li>ربط مخرجات الكلية باحتياجات سوق العمل وصناعات التصميم المختلفة لضمان فاعلية الخريجين.</li>
                            </ul>
                          </div>
                        </div>
                      )}

                      <div className="dept-title rounded-xl transition-all" onClick={() => toggleAccordion("about_system")}>
                        <div className="flex justify-between items-center p-3 bg-white/5 hover:bg-white/10 border border-white/5 cursor-pointer rounded-xl text-slate-200 font-extrabold text-xs">
                          <span>نظام الدراسة والدرجات العلمية والقبول</span>
                          <ChevronDown className={`w-4 h-4 transition-transform ${expandedAccordions.about_system ? "rotate-180" : ""}`} />
                        </div>
                      </div>
                      
                      {expandedAccordions.about_system && (
                        <div className="p-4 bg-white/5 border border-white/10 rounded-xl text-xs space-y-3 leading-relaxed text-slate-300">
                          <div>
                            <span className="font-bold text-indigo-400 block mb-1">نظام الدراسة بالكلية:</span>
                            <p className="text-[#94a3b8]">نظام الفصول الدراسية (الساعات المعتمدة) بحد أدنى ثمانية فصول دراسية (4 سنوات) لنيل درجة البكالوريوس.</p>
                          </div>
                          <div className="border-t border-white/5 pt-2">
                            <span className="font-bold text-indigo-400 block mb-1">الشهادات الممنوحة:</span>
                            <ul className="list-disc pr-4 text-[#94a3b8] space-y-0.5">
                              <li>درجة البكالوريوس في الفنون والتصميم (حسب التخصص العلمي).</li>
                              <li>درجة الماجستير في تخصصات الفنون والتصميم (البرنامج العالي بالكلية).</li>
                            </ul>
                          </div>
                          <div className="border-t border-white/5 pt-2">
                            <span className="font-bold text-indigo-400 block mb-1">شروط عامة للقبول:</span>
                            <p className="text-[#94a3b8]">أن يكون المتقدم حاصلاً على شهادة الثانوية العامة بتقدير مقبول فأعلى، مع شرط اجتياز <span className="text-amber-400 font-bold">امتحان القدرات الفني والعلمي</span> المحدد من الكلية والمقابلة الشخصية للقسم المطلوب.</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* ========== Tab 2: Departments and Programs ========== */}
                {activeGuideTab === "tab-depts" && (
                  <div className="space-y-4">
                    <div className="p-3 bg-white/5 border border-white/10 rounded-xl text-xs font-bold text-slate-200">
                      تتكون كلية الفنون والتصميم من الأقسام العلمية التخصصية التالية التي تمنح درجات البكالوريوس والماجستير:
                    </div>

                    {/* Department 1 details */}
                    <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/5 shadow-sm">
                      <div className="p-3.5 bg-white/5 text-slate-100 font-extrabold text-xs flex justify-between items-center border-b border-white/5">
                        <span className="flex items-center gap-1 text-indigo-400"><School className="w-4 h-4 ml-1 text-indigo-400" /> قسم التصميم الداخلي (الديكور)</span>
                      </div>
                      <div className="p-3.5 text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>يعنى بدراسة وتحليل وتصميم الفراغات المعمارية الداخلية المختلفة (السكنية، الإدارية، التجارية، والمتاحف). يشمل البرنامج دراسات الأثاث وتفاصيله، نظريات وتطبيقات الإضاءة واللون، الخامات ومواصفات التشطيب الفني، وإعداد الرسومات التنفيذية المعمارية والنمذجة ثلاثية الأبعاد باستخدام أرقى البرمجيات الهندسية المعاصرة.</p>
                      </div>
                    </div>

                    {/* Department 2 details */}
                    <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/5 shadow-sm">
                      <div className="p-3.5 bg-white/5 text-slate-100 font-extrabold text-xs flex justify-between items-center border-b border-white/5">
                        <span className="flex items-center gap-1 text-[#f59e0b]"><Palette className="w-4 h-4 ml-1 text-amber-500" /> قسم الفنون الجميلة والتطبيقية</span>
                      </div>
                      <div className="p-3.5 text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>من أعرق أقسام الكلية، ويضم تخصصات نوعية غنية:</p>
                        <ul className="list-disc pr-4 space-y-1 text-slate-350">
                          <li><span className="font-bold text-white">الرسم والتصوير:</span> صقل موهبة المبدع على توظيف الألوان الزيتية، المائية، والتقنيات المعاصرة لتجسيد المفاهيم والأفكار الفنية الفريدة.</li>
                          <li><span className="font-bold text-white">النحت المجسم:</span> دراسة المنظور والنمذجة ثلاثية الأبعاد بشتى الخامات الصلبة والمرنة كالحجر، الرخام، الطين والبرونز.</li>
                          <li><span className="font-bold text-white">الخزف الفني والتطبيقي:</span> تشكيل الفخار والخزف ودراسة كيمياء وميكانيكا التزجيج والأفران ومستلزمات الإنتاج الخزفي الفاخر.</li>
                          <li><span className="font-bold text-white">التصميم الجرافيكي والديكور الزخرفي والإعلانات:</span> مواءمة التصميم البصري والإعلاني وقواعد الطباعة، وتأهيل المصممين في عوالم الهويات البصرية والبرمجيات الغرافيكية وتصميم التغليف وعلم الإعلان والتسويق الرقمي بلمسات فنية راقية.</li>
                        </ul>
                      </div>
                    </div>

                    {/* Department 3 details */}
                    <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/5 shadow-sm">
                      <div className="p-3.5 bg-white/5 text-slate-100 font-extrabold text-xs flex justify-between items-center border-b border-white/5">
                        <span className="flex items-center gap-1 text-blue-400"><BookOpen className="w-4 h-4 ml-1 text-blue-400" /> قسم الفنون المرئية (السمعية والبصرية)</span>
                      </div>
                      <div className="p-3.5 text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>يتماشى مع تطور الفضاء الإعلامي والإنتاج المعاصر، ويشمل الشعب والبرامج الدقيقة التالية:</p>
                        <ul className="list-disc pr-4 space-y-1 text-slate-350">
                          <li><span className="font-bold text-white">شعبة السينما والتلفزيون الإخراجي:</span> دراسة نظريات وتطبيقات الإخراج وإنتاج المحتوى البصري وبنية المشاهد السينمائية والمسلسلات.</li>
                          <li><span className="font-bold text-white">شعبة الرسوم المتحركة (الأنيميشن):</span> دراسة صناعة الرسوم المتحركة ثنائية وثلاثية الأبعاد وتصميم الشخصيات والقصص المصورة والتحريك الرقمي المبتكر.</li>
                          <li><span className="font-bold text-white">شعبة السيناريو وكتابة المحتوى البصري:</span> تأصيل أسس كتابة الحبكة، الحوار، السيناريو وصياغة الأفكار الدرامية والتلفزيونية والقصصية.</li>
                          <li><span className="font-bold text-white">شعبة المونتاج وتعديل وتحرير الفيديو:</span> إتقان البرمجيات الاحترافية، وتأطير المونتاج البصري وهندسة الألوان والنسق الفيلمي الإعلاني والسينمائي.</li>
                        </ul>
                      </div>
                    </div>

                    {/* Department 4 details */}
                    <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/5 shadow-sm">
                      <div className="p-3.5 bg-white/5 text-slate-100 font-extrabold text-xs flex justify-between items-center border-b border-white/5">
                        <span className="flex items-center gap-1 text-emerald-400"><PenTool className="w-4 h-4 ml-1 text-emerald-400" /> قسم الفنون المسرحية (المسرح والدراما)</span>
                      </div>
                      <div className="p-3.5 text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>يعنى بتأسيس وتأهيل رواد الحركة المسرحية الليبية ومحاضني الإبداع الدرامي، وينقسم إلى:</p>
                        <ul className="list-disc pr-4 space-y-1 text-slate-355">
                          <li><span className="font-bold text-white">التمثيل والإخراج المسرحي:</span> صقل لغة الجسد الإيمائية، مخارج الحروف والإلقاء المسرحي وعلم قيادة وتحريك الممثلين على خشبات المسرح.</li>
                          <li><span className="font-bold text-white">السينوغرافيا والديكور المسرحي البصري:</span> هندسة وتصميم المناظر المسرحية والمؤثرات الضوئية وهندسة الملابس والإكسسوارات لخلق الفضاء الدرامي الأيقوني.</li>
                          <li><span className="font-bold text-white">النقد والدراما والأدب المسرحي:</span> تفكيك النصوص المسرحية والدرامية وتحليل العروض وسوسيولوجيا تاريخ الفن المسرحي ونظريات الدراما.</li>
                        </ul>
                      </div>
                    </div>

                    {/* Department 5 details */}
                    <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/5 shadow-sm">
                      <div className="p-3.5 bg-white/5 text-slate-100 font-extrabold text-xs flex justify-between items-center border-b border-white/5">
                        <span className="flex items-center gap-1 text-rose-400"><Database className="w-4 h-4 ml-1 text-rose-400" /> قسم الفنون الموسيقية (الموسيقى والتربية الموسيقية)</span>
                      </div>
                      <div className="p-3.5 text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>يرتكز على المنهج الأكاديمي الموسيقي لترقية الإحساس والفكر الصوتي والنظري، ويمتد برنامجه التخصصي ليركز على:</p>
                        <ul className="list-disc pr-4 space-y-1 text-slate-355">
                          <li><span className="font-bold text-white">العزف على الآلات الموسيقية:</span> التدريب الأكاديمي لآلات العود، القانون، الناي، والكمان (الشرقي) وللبيانو والآلات الوترية والنفخية (الغربي الكلاسيكي).</li>
                          <li><span className="font-bold text-white">النظريات الأكاديمية والتأليف الموسيقي والهارموني:</span> دراسة لغات النوت وتشكيل النغم التوافقي واستيعاب فنون التوزيع والتوليف الصوتي البورتريهي.</li>
                          <li><span className="font-bold text-white">التربية الموسيقية وهندسة الصوت والتسجيل:</span> إعداد كوادر مخصصة لتدريس الموسيقى بالمدارس وترسيخ الثنائيات الجمالية، مع مبادئ وأسس تسجيلات الأستوديو الاحترافية وبناء المنظومة الصوتية الفنية الرقمية.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                {/* ========== Tab 3: Student Rights ========== */}
                {activeGuideTab === "tab-rights" && (
                  <div className="space-y-4 text-xs leading-relaxed text-slate-300">
                    <div className="bg-[#10b981]/5 rounded-2xl p-4 border border-[#10b981]/20 text-emerald-300">
                      <h4 className="font-bold mb-2 flex items-center gap-1 text-teal-400">
                        <Shield className="w-4 h-4 ml-1 inline text-teal-400" /> لوائح الدراسة والامتحانات وحقوق الطالب الأكاديمية (وفقاً للائحة 501 المعتمدة):
                      </h4>
                      <p className="text-[#94a3b8] mb-3 text-xs">
                        تنظم "لائحة الدراسة والامتحانات والترشح" بجامعة طرابلس كافة الحقوق والواجبات المترتبة على الطالب وأعضاء هيئة التدريس بشكل تام ونزيه وعادل على النحو التالي:
                      </p>
                      
                      <div className="space-y-3">
                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-right">
                          <span className="font-bold text-white text-xs block mb-1">1. الغياب والحرمان من دخول الامتحانات (النسبة الحرجة 25%):</span>
                          <p className="text-slate-300 leading-relaxed text-xs">
                            حضور المحاضرات النظرية والتطبيقات المهنية والعملية إلزامي. يعاقب الطالب بــ <span className="text-red-400 font-bold font-mono">الحرمان الأكاديمي</span> من دخول الامتحانات النهائية للمقرر إذا تجاوزت غياباته غياب نسبة <span className="text-red-400 font-bold font-mono">25%</span> من إجمالي الساعات المقررة للتدريس في الفصل الدراسي بدون عذر طبي أو قاهري مقبول تقتنع به إدارة القسم ومجلس الكلية بشكل رسمي، ويرصد له تقدير "محروم" في نتائج المقررات كرسوب حتمي.
                          </p>
                        </div>

                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-right">
                          <span className="font-bold text-white text-xs block mb-1">2. ضوابط الإنذار الأكاديمي والتحذيرات:</span>
                          <p className="text-slate-300 leading-relaxed text-xs">
                            يُعرض الطالب لوضع <span className="text-amber-400 font-bold">الإنذار الأكاديمي</span> إذا تدنى معدله الدراسي التراكمي (CGPA) عن النسبة المقبولة وهي <span className="text-amber-400 font-bold font-mono">60%</span> (أو ما يعادل <span className="text-amber-400 font-bold font-mono">2.00</span> من أصل <span className="font-mono">4.00</span> نقاط) في نهاية أي فصل دراسي. يمنح الطالب فرصة إضافية قدرها فصليين تاليين متتاليين لرفع هذا المعدل للنسبة الطبيعية، وفي حال الإخفاق الأكاديمي المستمر للمرة الثالثة يُفصل الطالب لتوضيع مسار بديل بالجامعة.
                          </p>
                        </div>

                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-right">
                          <span className="font-bold text-white text-xs block mb-1">3. حق التظلم والطعن وإعادة مراجعة كراسة الإجابات النهائية:</span>
                          <p className="text-slate-300 leading-relaxed text-xs">
                            يملك الطالب الحق الرسمي والشرعي في تقديم طلب إعادة مراجعة تفصيلية وتحكيم موضوعي لكراسة الإجابة للامتحان النهائي في المقررات، ويجب تقديم التظلم والاعتراض خلال <span className="text-amber-400 font-bold font-mono">10 أيام عمل</span> من إعلان ونشر النتائج الرسمية المصدقة للقسم عبر نموذج معد بمكتب مسجل الكلية، ويدرس الطلب من لجنة علمية محايدة في القسم لإنصافه التام.
                          </p>
                        </div>

                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-right">
                          <span className="font-bold text-white text-xs block mb-1">4. تجميد وإيقاف القيد وتأجيل الدراسة للضرورة:</span>
                          <p className="text-slate-300 leading-relaxed text-xs">
                            يحق للطالب وبموافقة الكلية المسبقة التماس إيقاف قيده الدراسي مؤقتاً لظروف صحية، اجتماعية، أو قهرية تدعمها مستندات رسمية. ينص القانون على عدم تجاوز فصليين متتالين لإيقاف القيد تجنباً لإلغاء القيد التام وإقصاء السجل لملف الطالب.
                          </p>
                        </div>

                        <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-right">
                          <span className="font-bold text-white text-xs block mb-1">5. الإشراف العلمي الأكاديمي وساعات الإرشاد للتخرج:</span>
                          <p className="text-slate-300 leading-relaxed text-xs">
                            يحق لكل طالب متبقٍّ له ساعات مشروع تخرج تخصيصية الاستفادة من جدول الساعات المكتبية والإرشادية الإجبارية لأعضاء هيئة التدريس بحد أدنى <span className="text-teal-400 font-bold">ساعتين أسبوعياً</span> لتأطير ومراجعة البحث ومتابعة المشرف العلمي بصورة دورية سليمة.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ========== Tab 4: Academic Terms ========== */}
                {activeGuideTab === "tab-terms" && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">الساعة المعتمدة (Credit Hour)</span>
                      <p className="text-slate-300 text-xs">وحدة قياس زمنية لتحديد وزن المادة الأكاديمية ونشاطها الأسبوعي (مثل 2 ساعات للمحاضرات النظرية، و4 ساعات تطبيقية تعادل ساعة أو ساعتين معتمدتين بجدول الطالب).</p>
                    </div>

                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">المعدل التراكمي (GPA / CGPA)</span>
                      <p className="text-slate-300 text-xs">مجموع الدرجات المئوية أو النقاط التي ينالها الطالب بالمقررات مقارنة برصيد مجموع فصول ومقررات القيد، ويحسب كمؤشر تفصيلي لمستوى تحصيل الطالب الأكاديمي العام.</p>
                    </div>

                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">المشرف الأكاديمي (Academic Advisor)</span>
                      <p className="text-slate-300 text-xs">أستاذ وعضو هيئة تدريس بالكلية يكلف لمساعدة الطالب وإرشاده بكيفية اختيار وتسجيل المقررات المناسبة وبناء الجداول وحل معوقات المسيرة العلمية.</p>
                    </div>

                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">إيقاف القيد الجامعي (Frozen Registration)</span>
                      <p className="text-slate-300 text-xs">تجميد أو تعليق مؤقت للقيد الأكاديمي وحساب السجلات للفصول طوعياً لأعذار مبررة مقبولة بموافقة رسمية من عمادة وإدارة الكلية دون أن يترتب عليه فصل الطالب.</p>
                    </div>

                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">المقرر المسبق (Prerequisite Requirement)</span>
                      <p className="text-slate-300 text-xs">مقرر دراسي وأسس تخصصي يلتزم الطالب باجتيازه والنجاح فيه أولاً كشرط ضروري مسبق قبل تمكينه من تسجيل المقرر المتقدم أو المرتبط به بالفصول الموالية.</p>
                    </div>

                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">الحرمان الأكاديمي (Exam Herman)</span>
                      <p className="text-slate-300 text-xs">قرار رسمي يفيد بعدم أحقية الطالب بدخول الامتحان النهائي لمادة ما بسبب تجاوزه لنسبة غياب غير مبررة تفوق 25% من المحاضرات، ويرصد له درجات راسبة حتمية.</p>
                    </div>

                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">فترة الإسقاط والإضافة (Add/Drop Period)</span>
                      <p className="text-slate-300 text-xs">نافذة زمنية محدودة بنهاية الأسبوع الأول من انطلاقة الفصول تتيح للطلاب تعديل مقرراتهم المسجلة بالحذف الودي أو إضافة مواد مسموحة مع مشرفيهم الأكادميين.</p>
                    </div>

                    <div className="p-4 bg-white/5 border border-white/10 rounded-2xl hover:border-indigo-500/50 transition">
                      <span className="font-extrabold text-indigo-400 block pb-1">الفصل الأكاديمي (Academic Dismissal)</span>
                      <p className="text-slate-300 text-xs">قرار نهائي لإنهاء السجل الدراسي وقيد الطالب بالكلية بسبب استنفاد كافة فرص رفع معدلات التراكمي عن 60% بعد 3 إنذارات أكاديمية متتالية.</p>
                    </div>
                  </div>
                )}

              </div>

              <div className="flex gap-2 pt-4 border-t border-white/10 mt-4">
                <button 
                  className="w-full bg-blue-600 text-white rounded-xl py-2.5 text-xs font-bold hover:bg-blue-500 transition shadow-lg shadow-blue-950/50 cursor-pointer" 
                  onClick={() => setShowGuideModal(false)}
                >
                  حفظ وإغلاق
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
