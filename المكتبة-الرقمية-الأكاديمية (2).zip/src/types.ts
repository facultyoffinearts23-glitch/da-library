/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Book {
  id: string;
  title: string;
  author: string;
  tag: "specialized" | "general" | "research" | "projects" | string;
  hasFile?: boolean;
  fileUrl?: string;
  year?: string;
  timestamp: number;
}

export interface Artwork {
  id: string;
  workTitle: string;
  studentName: string;
  supervisorName: string;
  year: string;
  imageUrl: string;
  timestamp: number;
}

export type UserRole = "visitor" | "librarian" | "admin";

export type GuideTab = "tab-about" | "tab-depts" | "tab-rights" | "tab-terms";
